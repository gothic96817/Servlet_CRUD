package acetest.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import acetest.dto.UserResponseDTO;
import acetest.model.LoginBean;



public class UserDAO {
	public static Connection con=null;
	static {
		con=MyConnection.getConnection();
	}
	
	public ArrayList<UserResponseDTO> selectUser(LoginBean bean) {
		ArrayList<UserResponseDTO> list=new ArrayList<>();
		String sql="SELECT * FROM users WHERE name='"+bean.getName()+"' AND password='"+bean.getPassword()+"'";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery(sql);
			while (rs.next()) {
				UserResponseDTO dto=new UserResponseDTO();
				dto.setEmail(rs.getString("email"));
				dto.setPassword(rs.getString("password"));
				dto.setRole(rs.getInt("role"));
				dto.setId(rs.getInt("id"));
				dto.setName(rs.getString("name"));
				list.add(dto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	public ArrayList<UserResponseDTO> selectAll(){
		ArrayList<UserResponseDTO> list=new ArrayList<>();
		String sql="SELECT * FROM users";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery(sql);
			while (rs.next()) {
				UserResponseDTO dto=new UserResponseDTO();
				dto.setEmail(rs.getString("email"));
				dto.setPassword(rs.getString("password"));
				dto.setRole(rs.getInt("role"));
				dto.setId(rs.getInt("id"));
				dto.setName(rs.getString("name"));
				list.add(dto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

}
