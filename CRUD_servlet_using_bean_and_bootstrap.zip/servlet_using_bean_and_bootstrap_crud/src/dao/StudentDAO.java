package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.bean.Student;

public class StudentDAO {
	private Connection con;

	public StudentDAO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentDAO(Connection con) {
		super();
		this.con = con;
	}
	
	public boolean addstudent(Student student)
	{
		boolean f=false;
		try {
			String sql="insert into student(name,dob,address,qualification,email) values(?,?,?,?,?)";
			
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, student.getFullname());
			ps.setString(2, student.getDob());
			ps.setString(3, student.getAddress());
			ps.setString(4, student.getQualification());
			ps.setString(5, student.getEmail());			
			
			int i=ps.executeUpdate();
			
			if(i==1)
			{
				f=true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;		
	}
	
	public List<Student> getAllStudent()
	{
	List<Student> list=new ArrayList<Student>();
	Student bean=null;
	try {
		String sql="select * from student";
		PreparedStatement ps=con.prepareStatement(sql);
		
		ResultSet rs=ps.executeQuery();
		
		while(rs.next())
		{
			bean=new Student();
			bean.setId(rs.getInt(1));
			bean.setFullname(rs.getString(2));
			bean.setDob(rs.getString(3));
			bean.setAddress(rs.getString(4));
			bean.setQualification(rs.getString(5));
			bean.setEmail(rs.getString(6));
			list.add(bean);
		}
	} catch (Exception e) {
		// TODO: handle exception
	}
	return list;
		
	}
	
	public Student getStudentById(int id)
	{
		Student bean=null;
		try {
			String sql="select * from student where id=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, id);
			
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				bean=new Student();
				bean.setId(rs.getInt(1));
				bean.setFullname(rs.getString(2));
				bean.setDob(rs.getString(3));
				bean.setAddress(rs.getString(4));
				bean.setQualification(rs.getString(5));
				bean.setEmail(rs.getString(6));
				
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return bean;
	}
	
	public boolean updatestudent(Student student)
	{
		boolean f=false;
		try {
			String sql="update student set name=?,dob=?,address=?,qualification=?,email=? where id=?";
			
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, student.getFullname());
			ps.setString(2, student.getDob());
			ps.setString(3, student.getAddress());
			ps.setString(4, student.getQualification());
			ps.setString(5, student.getEmail());
			ps.setInt(6, student.getId());
			
			int i=ps.executeUpdate();
			
			if(i==1)
			{
				f=true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;		
	}
	
	public boolean deletestudent(int id)
	{
		boolean f=false;			
		try {
			
			String sql="delete from student where id=?";
			
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, id);
			
			int i= ps.executeUpdate();
			
			if(i==1)
			{
				f=true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}
	
}

